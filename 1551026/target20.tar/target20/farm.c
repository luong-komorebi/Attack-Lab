/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_240()
{
    return 3284633928U;
}

void setval_328(unsigned *p)
{
    *p = 2496104776U;
}

unsigned getval_354()
{
    return 3281031256U;
}

unsigned getval_120()
{
    return 2425393496U;
}

void setval_348(unsigned *p)
{
    *p = 1493036697U;
}

unsigned addval_281(unsigned x)
{
    return x + 3251079496U;
}

unsigned addval_461(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_452(unsigned x)
{
    return x + 1358399960U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_189()
{
    return 2428635601U;
}

unsigned addval_406(unsigned x)
{
    return x + 2495777209U;
}

unsigned getval_154()
{
    return 2464188744U;
}

unsigned getval_339()
{
    return 2425405961U;
}

unsigned addval_209(unsigned x)
{
    return x + 3676357249U;
}

unsigned addval_174(unsigned x)
{
    return x + 2430638408U;
}

unsigned getval_264()
{
    return 3674260105U;
}

void setval_218(unsigned *p)
{
    *p = 3227570569U;
}

unsigned addval_127(unsigned x)
{
    return x + 2425409801U;
}

unsigned addval_229(unsigned x)
{
    return x + 2497743176U;
}

void setval_212(unsigned *p)
{
    *p = 3523265161U;
}

unsigned getval_382()
{
    return 3682913801U;
}

void setval_145(unsigned *p)
{
    *p = 3281047177U;
}

unsigned addval_177(unsigned x)
{
    return x + 3234124169U;
}

unsigned addval_442(unsigned x)
{
    return x + 3677933065U;
}

unsigned getval_128()
{
    return 3285289325U;
}

unsigned getval_239()
{
    return 3526935177U;
}

void setval_430(unsigned *p)
{
    *p = 3252717896U;
}

unsigned addval_390(unsigned x)
{
    return x + 3378565513U;
}

unsigned addval_300(unsigned x)
{
    return x + 3225997705U;
}

unsigned getval_116()
{
    return 3525365257U;
}

void setval_302(unsigned *p)
{
    *p = 2430634312U;
}

void setval_142(unsigned *p)
{
    *p = 3465104358U;
}

unsigned getval_164()
{
    return 2497743176U;
}

unsigned addval_119(unsigned x)
{
    return x + 2425409929U;
}

void setval_161(unsigned *p)
{
    *p = 3767101591U;
}

unsigned getval_235()
{
    return 3674784393U;
}

unsigned addval_478(unsigned x)
{
    return x + 3375419017U;
}

void setval_184(unsigned *p)
{
    *p = 3281047179U;
}

unsigned addval_173(unsigned x)
{
    return x + 3352201582U;
}

unsigned addval_199(unsigned x)
{
    return x + 3380924825U;
}

void setval_325(unsigned *p)
{
    *p = 3286272328U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
