/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_160()
{
    return 3347663125U;
}

unsigned getval_153()
{
    return 2428995912U;
}

unsigned addval_396(unsigned x)
{
    return x + 3281031248U;
}

unsigned getval_358()
{
    return 3757228920U;
}

unsigned addval_278(unsigned x)
{
    return x + 2425393240U;
}

void setval_292(unsigned *p)
{
    *p = 1477154225U;
}

unsigned addval_174(unsigned x)
{
    return x + 3351742792U;
}

void setval_393(unsigned *p)
{
    *p = 2428995912U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_399(unsigned *p)
{
    *p = 3223372425U;
}

void setval_281(unsigned *p)
{
    *p = 3676360329U;
}

void setval_299(unsigned *p)
{
    *p = 3223375369U;
}

void setval_170(unsigned *p)
{
    *p = 2425406089U;
}

unsigned getval_268()
{
    return 2496760264U;
}

unsigned addval_448(unsigned x)
{
    return x + 3252717896U;
}

unsigned getval_215()
{
    return 3229929929U;
}

void setval_386(unsigned *p)
{
    *p = 3685008009U;
}

unsigned addval_154(unsigned x)
{
    return x + 3269495112U;
}

unsigned addval_441(unsigned x)
{
    return x + 3532964489U;
}

unsigned getval_225()
{
    return 3353381192U;
}

void setval_404(unsigned *p)
{
    *p = 3536114057U;
}

unsigned addval_204(unsigned x)
{
    return x + 3385118345U;
}

unsigned addval_492(unsigned x)
{
    return x + 2425406153U;
}

void setval_319(unsigned *p)
{
    *p = 2430634312U;
}

void setval_432(unsigned *p)
{
    *p = 2429649311U;
}

unsigned getval_110()
{
    return 2429655309U;
}

void setval_251(unsigned *p)
{
    *p = 3353381192U;
}

unsigned addval_236(unsigned x)
{
    return x + 3223375561U;
}

unsigned addval_475(unsigned x)
{
    return x + 2446231834U;
}

void setval_349(unsigned *p)
{
    *p = 3674263177U;
}

unsigned getval_300()
{
    return 3268315439U;
}

unsigned getval_389()
{
    return 3534013065U;
}

unsigned addval_212(unsigned x)
{
    return x + 3526939017U;
}

void setval_247(unsigned *p)
{
    *p = 3221802633U;
}

unsigned addval_461(unsigned x)
{
    return x + 3526410889U;
}

unsigned getval_365()
{
    return 3677930120U;
}

unsigned getval_308()
{
    return 3269495112U;
}

void setval_224(unsigned *p)
{
    *p = 3353381192U;
}

unsigned addval_105(unsigned x)
{
    return x + 3523793289U;
}

unsigned getval_295()
{
    return 2425409993U;
}

void setval_446(unsigned *p)
{
    *p = 3286272328U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
