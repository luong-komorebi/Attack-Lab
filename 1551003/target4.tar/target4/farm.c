/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_379()
{
    return 2425378846U;
}

unsigned addval_475(unsigned x)
{
    return x + 3347662903U;
}

void setval_431(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_398()
{
    return 2462550344U;
}

unsigned addval_243(unsigned x)
{
    return x + 465801304U;
}

unsigned addval_289(unsigned x)
{
    return x + 2425641193U;
}

unsigned addval_467(unsigned x)
{
    return x + 3347925156U;
}

unsigned getval_372()
{
    return 1807996940U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_165(unsigned x)
{
    return x + 3269495112U;
}

unsigned addval_390(unsigned x)
{
    return x + 3284306306U;
}

unsigned addval_141(unsigned x)
{
    return x + 2430634312U;
}

void setval_405(unsigned *p)
{
    *p = 3221802637U;
}

void setval_364(unsigned *p)
{
    *p = 3532964489U;
}

unsigned getval_423()
{
    return 3284304172U;
}

void setval_124(unsigned *p)
{
    *p = 2430634440U;
}

unsigned addval_292(unsigned x)
{
    return x + 3529559689U;
}

void setval_499(unsigned *p)
{
    *p = 3281044105U;
}

unsigned addval_193(unsigned x)
{
    return x + 3229926024U;
}

void setval_239(unsigned *p)
{
    *p = 3525366155U;
}

void setval_347(unsigned *p)
{
    *p = 3821261192U;
}

unsigned addval_432(unsigned x)
{
    return x + 3252717896U;
}

unsigned addval_293(unsigned x)
{
    return x + 3224949129U;
}

unsigned addval_302(unsigned x)
{
    return x + 3378565513U;
}

unsigned addval_376(unsigned x)
{
    return x + 2447411528U;
}

unsigned addval_286(unsigned x)
{
    return x + 3465141882U;
}

unsigned getval_403()
{
    return 1589822089U;
}

void setval_440(unsigned *p)
{
    *p = 3768142069U;
}

void setval_315(unsigned *p)
{
    *p = 3281047049U;
}

void setval_414(unsigned *p)
{
    *p = 3221802637U;
}

void setval_450(unsigned *p)
{
    *p = 3676361101U;
}

void setval_194(unsigned *p)
{
    *p = 2425474697U;
}

void setval_191(unsigned *p)
{
    *p = 3675836041U;
}

void setval_131(unsigned *p)
{
    *p = 2425409161U;
}

unsigned getval_185()
{
    return 1388495497U;
}

unsigned addval_336(unsigned x)
{
    return x + 3281179017U;
}

unsigned getval_433()
{
    return 3767093417U;
}

void setval_455(unsigned *p)
{
    *p = 3531129481U;
}

void setval_155(unsigned *p)
{
    *p = 3674788233U;
}

unsigned getval_180()
{
    return 3269495112U;
}

unsigned getval_149()
{
    return 3372798361U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
