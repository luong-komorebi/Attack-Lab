/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_198(unsigned x)
{
    return x + 2429000008U;
}

unsigned addval_121(unsigned x)
{
    return x + 3251079496U;
}

void setval_160(unsigned *p)
{
    *p = 2428995912U;
}

unsigned addval_326(unsigned x)
{
    return x + 2425411603U;
}

unsigned addval_102(unsigned x)
{
    return x + 3281031256U;
}

void setval_277(unsigned *p)
{
    *p = 2438515575U;
}

unsigned getval_471()
{
    return 2932052056U;
}

unsigned getval_125()
{
    return 2428995912U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_321()
{
    return 3269495112U;
}

unsigned addval_301(unsigned x)
{
    return x + 3223896457U;
}

unsigned getval_151()
{
    return 2464188744U;
}

unsigned getval_280()
{
    return 3767093809U;
}

void setval_305(unsigned *p)
{
    *p = 3599605216U;
}

void setval_221(unsigned *p)
{
    *p = 3524840073U;
}

void setval_348(unsigned *p)
{
    *p = 3531921033U;
}

void setval_426(unsigned *p)
{
    *p = 3372794249U;
}

void setval_489(unsigned *p)
{
    *p = 3281046025U;
}

unsigned addval_196(unsigned x)
{
    return x + 1522778504U;
}

unsigned addval_469(unsigned x)
{
    return x + 3525362073U;
}

unsigned getval_229()
{
    return 2425408153U;
}

void setval_215(unsigned *p)
{
    *p = 3281049225U;
}

void setval_287(unsigned *p)
{
    *p = 3281049224U;
}

unsigned getval_164()
{
    return 3380136585U;
}

unsigned getval_110()
{
    return 3281043849U;
}

unsigned getval_228()
{
    return 3680556681U;
}

void setval_255(unsigned *p)
{
    *p = 3223374473U;
}

unsigned addval_220(unsigned x)
{
    return x + 2425471369U;
}

void setval_199(unsigned *p)
{
    *p = 2497743176U;
}

unsigned getval_401()
{
    return 3224950281U;
}

unsigned getval_282()
{
    return 3380923033U;
}

void setval_432(unsigned *p)
{
    *p = 2430601544U;
}

unsigned getval_373()
{
    return 3268839918U;
}

void setval_335(unsigned *p)
{
    *p = 3767093363U;
}

void setval_210(unsigned *p)
{
    *p = 3223898761U;
}

unsigned addval_461(unsigned x)
{
    return x + 2430634312U;
}

unsigned addval_127(unsigned x)
{
    return x + 2462157174U;
}

unsigned getval_317()
{
    return 3232022921U;
}

void setval_437(unsigned *p)
{
    *p = 3229928073U;
}

unsigned addval_411(unsigned x)
{
    return x + 3286272072U;
}

unsigned addval_219(unsigned x)
{
    return x + 3534018185U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
