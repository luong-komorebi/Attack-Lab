/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_286(unsigned *p)
{
    *p = 3284633929U;
}

unsigned addval_461(unsigned x)
{
    return x + 1891025752U;
}

unsigned addval_109(unsigned x)
{
    return x + 3284633928U;
}

void setval_410(unsigned *p)
{
    *p = 1488789870U;
}

unsigned getval_481()
{
    return 3260557646U;
}

unsigned addval_107(unsigned x)
{
    return x + 2013516692U;
}

void setval_140(unsigned *p)
{
    *p = 2428995912U;
}

unsigned addval_353(unsigned x)
{
    return x + 3347663245U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_374(unsigned x)
{
    return x + 3531133321U;
}

void setval_385(unsigned *p)
{
    *p = 4190359945U;
}

unsigned getval_110()
{
    return 2430634344U;
}

unsigned getval_364()
{
    return 3677930121U;
}

void setval_318(unsigned *p)
{
    *p = 3286276424U;
}

void setval_425(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_496()
{
    return 2430634316U;
}

unsigned addval_183(unsigned x)
{
    return x + 3375940225U;
}

unsigned getval_150()
{
    return 3677408905U;
}

unsigned getval_198()
{
    return 3536113289U;
}

unsigned addval_259(unsigned x)
{
    return x + 3526935177U;
}

unsigned getval_112()
{
    return 3380920985U;
}

unsigned getval_422()
{
    return 3465375832U;
}

unsigned getval_463()
{
    return 3381969545U;
}

unsigned addval_457(unsigned x)
{
    return x + 3523792521U;
}

unsigned getval_391()
{
    return 2425409160U;
}

unsigned getval_409()
{
    return 3767093425U;
}

unsigned addval_100(unsigned x)
{
    return x + 3372798345U;
}

void setval_234(unsigned *p)
{
    *p = 3525886601U;
}

unsigned addval_255(unsigned x)
{
    return x + 3374370441U;
}

void setval_203(unsigned *p)
{
    *p = 3675836809U;
}

void setval_369(unsigned *p)
{
    *p = 2463009207U;
}

unsigned getval_242()
{
    return 3674784457U;
}

unsigned addval_475(unsigned x)
{
    return x + 3687039624U;
}

unsigned addval_448(unsigned x)
{
    return x + 3221803405U;
}

unsigned getval_484()
{
    return 3677933065U;
}

void setval_164(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_465(unsigned x)
{
    return x + 3222851977U;
}

void setval_468(unsigned *p)
{
    *p = 3223376264U;
}

unsigned addval_199(unsigned x)
{
    return x + 3353381192U;
}

unsigned getval_386()
{
    return 3252717896U;
}

unsigned getval_205()
{
    return 2446428598U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
