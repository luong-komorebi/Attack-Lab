/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_202(unsigned x)
{
    return x + 3347662924U;
}

void setval_177(unsigned *p)
{
    *p = 2425393368U;
}

void setval_321(unsigned *p)
{
    *p = 2428995944U;
}

unsigned getval_198()
{
    return 2423788635U;
}

void setval_336(unsigned *p)
{
    *p = 180574369U;
}

void setval_266(unsigned *p)
{
    *p = 2445773128U;
}

unsigned getval_275()
{
    return 3347662965U;
}

unsigned getval_209()
{
    return 3281031256U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_496(unsigned x)
{
    return x + 2430634312U;
}

unsigned addval_358(unsigned x)
{
    return x + 3523270281U;
}

void setval_425(unsigned *p)
{
    *p = 3281043851U;
}

unsigned getval_271()
{
    return 3281046169U;
}

void setval_189(unsigned *p)
{
    *p = 3525364361U;
}

void setval_298(unsigned *p)
{
    *p = 3232028297U;
}

void setval_315(unsigned *p)
{
    *p = 3375415689U;
}

void setval_378(unsigned *p)
{
    *p = 3221799297U;
}

unsigned addval_359(unsigned x)
{
    return x + 3523791501U;
}

unsigned addval_488(unsigned x)
{
    return x + 3375939977U;
}

void setval_142(unsigned *p)
{
    *p = 3224945035U;
}

void setval_107(unsigned *p)
{
    *p = 3281046025U;
}

unsigned getval_461()
{
    return 3224950413U;
}

unsigned addval_392(unsigned x)
{
    return x + 3221804681U;
}

unsigned getval_241()
{
    return 3284241407U;
}

void setval_253(unsigned *p)
{
    *p = 3224950441U;
}

unsigned getval_348()
{
    return 3531921033U;
}

void setval_230(unsigned *p)
{
    *p = 3525888649U;
}

unsigned getval_401()
{
    return 2430634328U;
}

unsigned getval_438()
{
    return 3682126473U;
}

void setval_251(unsigned *p)
{
    *p = 3353381192U;
}

unsigned addval_111(unsigned x)
{
    return x + 2430634440U;
}

unsigned addval_294(unsigned x)
{
    return x + 2430634344U;
}

void setval_465(unsigned *p)
{
    *p = 3221804685U;
}

unsigned addval_180(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_386()
{
    return 3281046153U;
}

void setval_480(unsigned *p)
{
    *p = 3767093492U;
}

void setval_426(unsigned *p)
{
    *p = 3525364353U;
}

unsigned addval_134(unsigned x)
{
    return x + 3375939976U;
}

void setval_295(unsigned *p)
{
    *p = 3281043849U;
}

void setval_223(unsigned *p)
{
    *p = 3524843145U;
}

unsigned addval_167(unsigned x)
{
    return x + 3353381192U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
