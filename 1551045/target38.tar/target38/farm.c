/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_234(unsigned *p)
{
    *p = 3281031192U;
}

void setval_195(unsigned *p)
{
    *p = 3267596632U;
}

unsigned addval_449(unsigned x)
{
    return x + 3284633928U;
}

void setval_329(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_296(unsigned x)
{
    return x + 883606360U;
}

void setval_359(unsigned *p)
{
    *p = 2462550344U;
}

void setval_497(unsigned *p)
{
    *p = 3281031256U;
}

unsigned addval_411(unsigned x)
{
    return x + 3284601160U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_337(unsigned x)
{
    return x + 2464188744U;
}

unsigned addval_374(unsigned x)
{
    return x + 2497087893U;
}

void setval_293(unsigned *p)
{
    *p = 3525362057U;
}

unsigned getval_403()
{
    return 3680553609U;
}

void setval_131(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_113(unsigned x)
{
    return x + 2462157260U;
}

void setval_198(unsigned *p)
{
    *p = 2425411209U;
}

unsigned getval_371()
{
    return 3675832713U;
}

void setval_274(unsigned *p)
{
    *p = 3221801609U;
}

unsigned addval_328(unsigned x)
{
    return x + 2965624461U;
}

void setval_476(unsigned *p)
{
    *p = 2464188744U;
}

void setval_381(unsigned *p)
{
    *p = 3524840073U;
}

unsigned addval_143(unsigned x)
{
    return x + 3221280393U;
}

unsigned addval_254(unsigned x)
{
    return x + 2464188744U;
}

unsigned getval_437()
{
    return 2430638408U;
}

unsigned getval_207()
{
    return 3380926089U;
}

unsigned getval_128()
{
    return 3525364425U;
}

unsigned getval_422()
{
    return 2425411201U;
}

void setval_490(unsigned *p)
{
    *p = 3372269961U;
}

unsigned getval_171()
{
    return 3526412937U;
}

unsigned getval_458()
{
    return 3674259849U;
}

unsigned addval_330(unsigned x)
{
    return x + 2425408137U;
}

void setval_386(unsigned *p)
{
    *p = 3524840073U;
}

void setval_389(unsigned *p)
{
    *p = 3674786433U;
}

unsigned addval_189(unsigned x)
{
    return x + 3286288712U;
}

void setval_184(unsigned *p)
{
    *p = 3682910593U;
}

void setval_488(unsigned *p)
{
    *p = 3281180297U;
}

unsigned addval_429(unsigned x)
{
    return x + 3676357001U;
}

void setval_183(unsigned *p)
{
    *p = 2497087820U;
}

unsigned getval_487()
{
    return 3525886345U;
}

void setval_214(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_180(unsigned x)
{
    return x + 2430634440U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
