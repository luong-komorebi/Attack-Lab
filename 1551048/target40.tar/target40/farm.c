/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_470(unsigned x)
{
    return x + 2428995912U;
}

unsigned addval_426(unsigned x)
{
    return x + 2425393240U;
}

unsigned getval_167()
{
    return 3284633928U;
}

unsigned getval_248()
{
    return 2462550344U;
}

void setval_340(unsigned *p)
{
    *p = 3284634056U;
}

void setval_128(unsigned *p)
{
    *p = 3281031256U;
}

unsigned getval_464()
{
    return 1342684651U;
}

unsigned getval_478()
{
    return 1208726810U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_191()
{
    return 2497743176U;
}

unsigned getval_273()
{
    return 2425405825U;
}

unsigned addval_400(unsigned x)
{
    return x + 919060873U;
}

unsigned addval_149(unsigned x)
{
    return x + 2425408137U;
}

void setval_142(unsigned *p)
{
    *p = 3600389500U;
}

unsigned getval_178()
{
    return 3523794441U;
}

unsigned getval_194()
{
    return 3353381192U;
}

void setval_435(unsigned *p)
{
    *p = 3599491669U;
}

unsigned getval_196()
{
    return 3376988553U;
}

unsigned getval_251()
{
    return 3674784137U;
}

void setval_105(unsigned *p)
{
    *p = 3227568777U;
}

unsigned getval_476()
{
    return 3286272320U;
}

unsigned getval_283()
{
    return 3767093362U;
}

unsigned getval_190()
{
    return 3286272328U;
}

unsigned addval_179(unsigned x)
{
    return x + 3224945033U;
}

unsigned addval_431(unsigned x)
{
    return x + 3525888649U;
}

unsigned getval_123()
{
    return 3674262153U;
}

unsigned getval_424()
{
    return 3767355567U;
}

unsigned addval_430(unsigned x)
{
    return x + 3281049289U;
}

unsigned addval_317(unsigned x)
{
    return x + 2445969905U;
}

unsigned addval_192(unsigned x)
{
    return x + 3229139337U;
}

void setval_349(unsigned *p)
{
    *p = 3767091296U;
}

unsigned getval_224()
{
    return 3374367177U;
}

unsigned addval_378(unsigned x)
{
    return x + 3374893705U;
}

unsigned addval_242(unsigned x)
{
    return x + 2425471369U;
}

void setval_116(unsigned *p)
{
    *p = 3224950408U;
}

unsigned addval_303(unsigned x)
{
    return x + 3523791497U;
}

void setval_471(unsigned *p)
{
    *p = 3767224332U;
}

void setval_274(unsigned *p)
{
    *p = 2425411209U;
}

unsigned addval_327(unsigned x)
{
    return x + 2429979002U;
}

unsigned getval_412()
{
    return 3372796617U;
}

unsigned addval_377(unsigned x)
{
    return x + 3675838089U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
