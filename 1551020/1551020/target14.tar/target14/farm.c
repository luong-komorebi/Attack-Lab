/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_263(unsigned x)
{
    return x + 1490487922U;
}

unsigned addval_285(unsigned x)
{
    return x + 2428995912U;
}

unsigned getval_119()
{
    return 2488837201U;
}

unsigned addval_190(unsigned x)
{
    return x + 2428993864U;
}

void setval_115(unsigned *p)
{
    *p = 1209891750U;
}

void setval_392(unsigned *p)
{
    *p = 3347646503U;
}

void setval_414(unsigned *p)
{
    *p = 3277324724U;
}

void setval_391(unsigned *p)
{
    *p = 3347662848U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_444(unsigned *p)
{
    *p = 2425409161U;
}

unsigned addval_436(unsigned x)
{
    return x + 2425541001U;
}

unsigned addval_497(unsigned x)
{
    return x + 3372798345U;
}

unsigned addval_366(unsigned x)
{
    return x + 3286272840U;
}

void setval_129(unsigned *p)
{
    *p = 2430632264U;
}

unsigned getval_357()
{
    return 2429651866U;
}

unsigned getval_230()
{
    return 3225997705U;
}

void setval_252(unsigned *p)
{
    *p = 3252717896U;
}

unsigned addval_238(unsigned x)
{
    return x + 3526935241U;
}

void setval_408(unsigned *p)
{
    *p = 3531915905U;
}

void setval_214(unsigned *p)
{
    *p = 3281178249U;
}

unsigned getval_204()
{
    return 3465076010U;
}

void setval_427(unsigned *p)
{
    *p = 3380924873U;
}

unsigned getval_411()
{
    return 2425406088U;
}

unsigned getval_183()
{
    return 2425409160U;
}

unsigned addval_301(unsigned x)
{
    return x + 3682910856U;
}

unsigned getval_291()
{
    return 3769190447U;
}

unsigned addval_244(unsigned x)
{
    return x + 3376992649U;
}

void setval_349(unsigned *p)
{
    *p = 2425409161U;
}

unsigned addval_324(unsigned x)
{
    return x + 3264811143U;
}

unsigned getval_267()
{
    return 3286288712U;
}

unsigned addval_197(unsigned x)
{
    return x + 3523269001U;
}

unsigned addval_220(unsigned x)
{
    return x + 3531919753U;
}

unsigned getval_372()
{
    return 3263806413U;
}

unsigned addval_186(unsigned x)
{
    return x + 3674784393U;
}

void setval_113(unsigned *p)
{
    *p = 3385118345U;
}

void setval_213(unsigned *p)
{
    *p = 3269495112U;
}

unsigned getval_175()
{
    return 3534016137U;
}

unsigned addval_343(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_104()
{
    return 3221802625U;
}

void setval_401(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_455(unsigned x)
{
    return x + 3372794521U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
