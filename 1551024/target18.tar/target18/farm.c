/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_352(unsigned *p)
{
    *p = 2425393240U;
}

void setval_234(unsigned *p)
{
    *p = 2425376877U;
}

unsigned addval_289(unsigned x)
{
    return x + 3267856712U;
}

unsigned addval_423(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_209(unsigned x)
{
    return x + 1479460744U;
}

void setval_309(unsigned *p)
{
    *p = 2428995656U;
}

unsigned addval_340(unsigned x)
{
    return x + 3281012762U;
}

void setval_256(unsigned *p)
{
    *p = 2428995912U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_381()
{
    return 3281046153U;
}

unsigned addval_494(unsigned x)
{
    return x + 3676357065U;
}

void setval_108(unsigned *p)
{
    *p = 1388429705U;
}

unsigned getval_402()
{
    return 3677935241U;
}

unsigned addval_440(unsigned x)
{
    return x + 3674786433U;
}

unsigned addval_387(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_351()
{
    return 3372796569U;
}

void setval_175(unsigned *p)
{
    *p = 3372796585U;
}

unsigned addval_485(unsigned x)
{
    return x + 3374367113U;
}

unsigned getval_105()
{
    return 3525364361U;
}

unsigned addval_312(unsigned x)
{
    return x + 3526940169U;
}

unsigned getval_488()
{
    return 2425536905U;
}

unsigned addval_447(unsigned x)
{
    return x + 2425411081U;
}

void setval_464(unsigned *p)
{
    *p = 3529561737U;
}

unsigned getval_276()
{
    return 3380920745U;
}

void setval_122(unsigned *p)
{
    *p = 3526416009U;
}

unsigned getval_335()
{
    return 3374369289U;
}

void setval_347(unsigned *p)
{
    *p = 3677410953U;
}

unsigned getval_221()
{
    return 3525362057U;
}

unsigned getval_409()
{
    return 2430635336U;
}

unsigned getval_254()
{
    return 3281043848U;
}

unsigned addval_431(unsigned x)
{
    return x + 3531131529U;
}

unsigned getval_102()
{
    return 2430642504U;
}

unsigned getval_281()
{
    return 3677929881U;
}

void setval_107(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_422(unsigned x)
{
    return x + 3229931149U;
}

unsigned getval_279()
{
    return 3286272320U;
}

unsigned getval_344()
{
    return 3767101530U;
}

unsigned getval_469()
{
    return 3523794569U;
}

unsigned addval_483(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_270()
{
    return 3674786505U;
}

unsigned addval_207(unsigned x)
{
    return x + 3286272456U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
